package com.springsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecurityBasicApplication.class, args);
	}

}
